<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BookingFormEditController extends Controller
{
    //
}
